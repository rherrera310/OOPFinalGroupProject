
public abstract class absClass {
	public abstract void gameOfThrones();
}
